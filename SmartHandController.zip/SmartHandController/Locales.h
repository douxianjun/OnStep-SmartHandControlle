// -----------------------------------------------------------------------------------
// Locales

// see Strings_xx.h for individual locale translations

// languages (one unique numeric code required for each)
#define L_de 1
#define L_en 2
#define L_es 3
#define L_fr 4
#define L_cn 5
