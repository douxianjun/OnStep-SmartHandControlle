#include <U8g2lib.h>
#include <U8x8lib.h>

// -----------------------------------------------------------------------------------
// Locale English (default,) ISO ISO639-1 language code "en"

// Fonts
// see https://github.com/olikraus/u8g2/wiki/fntlistall for the complete list of fonts
#define LF_CATALOGS u8g2_font_6x13_tf       //  9 pixel height//
#define LF_GREEK u8g2_font_unifont_t_greek  // 10 pixel height
#define LF_STANDARD u8g2_font_unifont_t_myfont  // 11 pixel height
#define LF_LARGE u8g2_font_unifont_t_myfont     // 12 pixel height         u8g2_font_wqy12_t_chinese1         u8g2_font_unifont_t_chinese1    u8g2_font_wqy12_t_gb2312   u8g2_font_unifont_t_myfont
/*#define LF_AA u8g2_font_unifont_t_chinese1
 * /
 */
// General
#define L_OK "成功"
#define L_ON "开"
#define L_OFF "关"
#define L_YES "是"
#define L_NO "不"
#define L_NOW "现在"
#define L_SETV "设置"
#define L_ALL "全部"
#define L_SET_STATE "设置观测点"
#define L_VALUE "值"
#define L_WITHIN "以内"
#define L_DISABLE "禁用"
#define L_CANCELED "已取消"
#define L_FAILED "失败"
#define L_DEGREE "度"
#define L_ARCSEC "角秒"
#define L_MICRON_PER_C "微米/ºC"
#define L_DAYS "天"

// common abbreviations
#define L_TELESCOPE "望远镜" // telescope
#define L_SEC_ABV "秒"     // seconds
#define L_MIN_ABV "分"     // minutes
#define L_HRS_ABV "时"     // hours
#define L_OFFSET_ABV "偏移"  // offset
#define L_TZ_ABV "时区"     // time-zone
#define L_RA "赤经"           // Right Ascension
#define L_DE "赤纬"           // Declination
#define L_DEC "赤纬"
#define L_AZ "方位"           // Azimuth
#define L_ALT "高度"         // Altitude
#define L_HH1 "汉化："
#define L_HH2 "狂风工作室"
// --------------------- menu, alignment -------------------

#define L_ALGN_RESUME "恢复对齐"
#define L_ALGN_SHOW_CORR "显示 Corr"
#define L_ALGN_CLEAR_CORR "清除 Corr"
#define L_ALGN_RESET_HOME "重置零位"
#define L_ALIGNMENT "校准"
#define L_ALGN_STAR_ALIGN "校准星"
#define L_ALGN_SHOW_MODEL "显示模型"
#define L_ALGN_CLEAR_MODEL "清除模型"
#define L_ALGN_RESET_HOME "重置零位"

#define L_ALGN_RESUME0 "重置"
#define L_ALGN_RESUME1 "回到零位"
#define L_ALGN_RESUME2 "日期/时间"
#define L_ALGN_RESUME3 "未设置!"
#define L_ALGN_RESUME4 "引导速率"
#define L_ALGN_RESUME5 "48X Set"

#define L_ALGN_REFINE_MSG1 "Setup & 3+ star"
#define L_ALGN_REFINE_MSG2 "align mount."
#define L_ALGN_REFINE_MSG3 "Goto bright star"
#define L_ALGN_REFINE_MSG4 "near NCP/SCP w/"
#define L_ALGN_REFINE_MSG5 "Dec in 50 to 80"
#define L_ALGN_REFINE_MSG6 "deg range N/S."
#define L_ALGN_REFINE_MSG7 "Answr YES below."
#define L_ALGN_REFINE_MSG8 "Use Polar Align"
#define L_ALGN_REFINE_MSG9 "adjust controls to"
#define L_ALGN_REFINE_MSG10 "center star again."
#define L_ALGN_REFINE_MSG11 "Optionally align"
#define L_ALGN_REFINE_MSG12 "the mount again."
#define L_ALGN_REFINE_MSG13 "Refine PA?"
#define L_ALGN_REFINE_MSG14 "Center star again"
#define L_ALGN_REFINE_MSG15 "using PA controls"

// ----------------------- menu, main ----------------------

// feature key menu
#define L_FKEY_GUIDE_RATE "引导速率"
#define L_FKEY_PULSE_GUIDE_RATE "引导脉冲率"
#define L_FKEY_UTILITY_LIGHT "照明"
#define L_FKEY_RETICLE "十字线"
#define L_FKEY_FOCUSER1 "聚焦器1"
#define L_FKEY_FOCUSER "聚焦器"
#define L_FKEY_FOCUSER2 "聚焦器2"
#define L_FKEY_ROTATOR "旋转器"
#define L_FKEY_FEATURE_KEYS "功能键"

// main menu root
#define L_MM_GOTO "指向"
#define L_MM_SYNC "同步"
#define L_MM_ALIGN "校准"
#define L_MM_PARKING "停机"
#define L_MM_TRACKING "跟踪"
#define L_MM_PEC "PEC校正"
#define L_MM_SETTINGS "设置"
#define L_MM_MAIN_MENU "主菜单"
	  
// park menu
#define L_PARK "停机位"
#define L_SETPARK "设定停机位"
#define L_UNPARK "解除停机位"
#define L_PARKING "停机中"
#define L_UNPARKING "解除停机中"

// tracking menu
#define L_TRK_START "开始跟踪"
#define L_TRK_STOP "停止跟踪"
#define L_TRK_SIDEREAL "恒星速率"
#define L_TRK_SOLAR "太阳速率"
#define L_TRK_LUNAR "月球速率"
#define L_TRK_RESET "速率重置"
#define L_TRK_FASTER "速率+0.02Hz"
#define L_TRK_SLOWER "速率-0.02Hz"
#define L_TRACKING "跟踪设置"
#define L_TRK_CF "完全补偿"
#define L_TRK_CR "大气折射补偿"
#define L_TRK_CO "关闭补偿"
#define L_TRK_CS "单轴补偿"
#define L_TRK_CD "双轴补偿"

// PEC menu
#define L_PEC_PLAY "播放"
#define L_PEC_STOP "停止"
#define L_PEC_CLEAR "清除"
#define L_PEC_RECORD "记录"
#define L_PEC_WRITENV "写入ROM"
#define L_PEC "PEC校正"
#define L_PEC_PLAYING "播放中"
#define L_PEC_STOPPED "已停止"
#define L_PEC_RECORDING "记录中"

// ---------------------- menu, mount ----------------------

// root menu
#define L_MOUNT_SPEED "Goto速度"
#define L_MOUNT_BL "回差"
#define L_MOUNT_LIMITS "极限"
#define L_MOUNT_PIER "架侧"
#define L_MOUNT_CONFIG "设定"

#define L_MOUNT_FASTEST "最快"
#define L_MOUNT_FASTER "较快"
#define L_MOUNT_DEFAULT_SPEED "默认速度"
#define L_MOUNT_SLOWER "较慢"
#define L_MOUNT_SLOWEST "最慢"
#define L_MOUNT_SPEED "Goto速度"

#define L_MOUNT_BL "回差设置"
#define L_MOUNT_LIMIT_H "地平设置"
#define L_MOUNT_LIMIT_O "天顶设置"
#define L_MOUNT_LIMIT_ME "子午线翻转（东）"
#define L_MOUNT_LIMIT_MW "子午线翻转（西）"

#define L_MOUNT_LIMITS "极限"
#define L_MOUNT_LIMIT_HORIZON "地平限制"
#define L_MOUNT_LIMIT_OVERHEAD "天顶限制"
#define L_MOUNT_LIMIT_MERIDIAN_EAST "子午线翻转限制（东）"
#define L_MOUNT_LIMIT_MERIDIAN_WEST "子午线翻转限制（西）"
#define L_MOUNT_PPS "首选架侧"
#define L_PPS_BEST "Best"
#define L_PPS_EAST "东侧"
#define L_PPS_WEST "西侧"

// -------------------- menu, settings ---------------------

// root menu
#define L_SET_DATE_TIME "日期/时间设置"
#define L_SET_SITE "观测点设置"
#define L_SET_FOCUSER "聚焦器"
#define L_SET_FOCUSER1 "聚焦器1"
#define L_SET_FOCUSER2 "聚焦器2"
#define L_SET_ROTATOR "旋转器"
#define L_SET_DISPLAY "显示设置"
#define L_SET_BUZ "蜂鸣器设置"
#define L_SET_MERIDIAN_FLIP "子午线翻转设置"
#define L_SET_CONFIG "其他设置"
#define L_SET_VERSION "固件版本"
#define L_SETTINGS "设定"

// date/time
#define L_SET_LOCAL_DATE "当地日期"
#define L_SET_LOCAL_PM "当地时间PM"
#define L_SET_LOCAL_DST "夏令时"

// display
#define L_SET_DISP_OFF "关闭屏显"
#define L_SET_DISP_CONT "对比度"
#define L_SET_DISP_DIM_TO "超时暗屏"
#define L_SET_DISP_BLANK_TO "超时关屏"
#define L_DISPLAY "显示设置"
#define L_SET_DISP_MSG1 "按下任意键"
#define L_SET_DISP_MSG2 "启动屏显"
#define L_SET_DISP_MIN "最小对比度"
#define L_SET_DISP_LOW "低对比度"
#define L_SET_DISP_HIGH "高对比度"
#define L_SET_DISP_MAX "最大对比度"
#define L_SET_DISP_CONTRAST "设定对比度"
#define L_SET_BUZZER "开启蜂鸣器?"

// meridian flips
#define L_SET_MF_AUTO "自动"
#define L_SET_MF_PAUSE "零位暂停"
#define L_SET_MF "子午线翻转"
#define L_SET_MF_AF "自动翻转?"
#define L_SET_MF_PF "暂停翻转?"

// site
#define L_SET_SITE_SELECT "选择观测点"
#define L_SET_SITE_LAT "纬度"
#define L_SET_SITE_LONG "经度"
#define L_SET_SITE_UTC "UTC偏移"
#define L_SET_SITE_TITLE "位置设定"
#define L_SET_SITE_NUM "位置"
#define L_SET_SITE_NUM_TITLE "位置列表"

// focuser
#define L_FOC_RET_HOME "返回零位"
#define L_FOC_AT_HOME  "位于零位"
#define L_FOCUSER "聚焦器"
#define L_FOC_AT_HALF "确认已置于半调焦行程?"
#define L_FOC_TC "温度补偿?"//温度补偿
#define L_FOC_TC_COEF "温度补偿系数"//温度补偿系数
#define L_FOC_TC_DEADBAND "温度补偿死区"//温度补偿死区
#define L_FOC_TC_DB_UNITS "微米"
#define L_FOC_BACKLASH "调焦间隙"
#define L_FOC_BL_UNITS "微米"

// rotator
#define L_ROT_RET_HOME "返回零位"
#define L_ROT_AT_HOME "位于零位"
#define L_ROT_DEROT "De-rotate"
#define L_ROT_PA "Move to PA"
#define L_ROT_REV "Reverse"
#define L_ROTATOR "Rotator"
#define L_ROT_AT_HOME_ZERO "At Home/Zero?"
#define L_ROT_REVERSE "Reverse"

// -------------------- menu, sync/goto --------------------

// root menu
#define L_SG_SOLSYS "太阳系天体"
#define L_SG_HERE "Here"
#define L_SG_USER "用户自定"
#define L_SG_FILTERS "筛选"
#define L_SG_COORDS "指定坐标"
#define L_SG_HOME "零位"
#define L_SG_SYNC "同步"
#define L_SG_GOTO "指向"

// return home or reset at home
#define L_SG_HOME1 "Goto Home will"
#define L_SG_HOME2 "clear the Model"
#define L_SG_HOME3 "Goto Home"
#define L_SG_HOME4 "Reset at"
#define L_SG_HOME5 "Goto"
#define L_SG_HOME6 "Home Position"
#define L_SG_NO_OBJECT "No Object"
#define L_SG_NO_INIT "Not Init'd"

// solsys
#define L_SG_SUN "太阳"
#define L_SG_MER "水星"
#define L_SG_VEN "金星"
#define L_SG_MAR "火星"
#define L_SG_JUP "木星"
#define L_SG_SAT "土星"
#define L_SG_URA "天王星"
#define L_SG_NEP "海王星"
#define L_SG_MOON "月球"
#define L_SG_SSOL "同步到太阳系天体"
#define L_SG_GSOL "太阳系天体列表"
#define L_SG_SOL_WARN1 "指向太阳"
#define L_SG_SOL_WARN2 "可能存在危险"
#define L_SG_GSUN "指向太阳"

// user catalogs
#define L_SG_USER_MSG1 "选择用户目录"
#define L_SG_USER_MSG2 "无目录"
#define L_SG_SYNC_USER "Sync User"
#define L_SG_GOTO_USER "Goto User"
#define L_SG_SYNC_USER_ITEM "同步用户项目"
#define L_SG_GOTO_USER_ITEM "指向用户项目"

// --------------------- menu, filters ---------------------

// root menu
#define L_SG_FILT_RESET "重置筛选项"
#define L_SG_FILT_HOR "高于地平线"
#define L_SG_FILT_CON "星座"
#define L_SG_FILT_TYP "类型"
#define L_SG_FILT_MAG "星等"
#define L_SG_FILT_NEAR "当前位置附近"
#define L_SG_FILT_VAR_MAX "变星-最大周期"
#define L_SG_FILT_DBL_MIN "双星-最小角距"
#define L_SG_FILT_DBL_MAX "双星-最大角距"
#define L_SG_FILT_ALLOW "筛选器列表"
#define L_SG_FILT_MSG1 "筛选器"
#define L_SG_FILT_MSG2 "重置"
#define L_SG_FILT_MSG3 "仅地平上方？"
#define L_SG_FILTER "Filter"

// filter constellation
#define L_SG_FILT_BY_CON "按条件筛选"

// filter type
#define L_SG_FILT_BY_TYPE "按类型筛选"

// filter magn
#define L_SG_FILT_BY_MAG "按星等筛选"

// filter nearby
#define L_SG_FILT_BY_NEAR "按附近范围筛选"

// filter dbl min sep
#define L_SG_FILT_BY_SEP_MIN "双星角距范围"
#define L_SG_SEP_MIN_MSG1 "Min Sep must"
#define L_SG_SEP_MIN_MSG2 "be < Max Sep."

// filter dbl max sep
#define L_SG_FILT_BY_SEP_MAX "双星角距范围"
#define L_SG_SEP_MAX_MSG1 "Max Sep must"
#define L_SG_SEP_MAX_MSG2 "be > Min Sep."

// filter var max per
#define L_SG_FILT_BY_PER_MAX "变星周期范围"

// ------------------- SmartController.h -----------------------
#define L_ESTABLISHING "正在"
#define L_CONNECTION "连接赤道仪"
#define L_WARNING "警告"
#define L_COORDINATES "坐标"
#define L_OBSERVED_PLACE "观测点."
#define L_WARNING "警告"
#define L_FAILED "失败"
#define L_REBOOT "重启"
#define L_DEVICE "设备"
#define L_STAR "恒星"
#define L_ALIGN_MSG1 "从列表"
#define L_ALIGN_MSG2 "选一颗星"
#define L_ABORTED "中止"
#define L_DISCONNECT_MSG1 "手控器"
#define L_DISCONNECT_MSG2 "未连接赤道仪"
#define L_SLEW_MSG1 "指向目标"
#define L_SLEW_MSG2 "已取消"
#define L_FKEY_GUIDE_DN "引导速度 -"
#define L_FKEY_GUIDE_UP "引导速度 +"
#define L_FKEY_PGUIDE_DN "PGuide Slower"
#define L_FKEY_PGUIDE_UP "PGuide Faster"
#define L_FKEY_LAMP_DN "Util Dimmer"
#define L_FKEY_LAMP_UP "Util Brighter"
#define L_FKEY_RETI_DN "Reticle Dimmer"
#define L_FKEY_RETI_UP "Reticle Brighter"
#define L_FKEY_FOC_DN "Focus Out"
#define L_FKEY_FOC_UP "Focus In"
#define L_FKEY_FOCF_DN "Focus Fast"
#define L_FKEY_FOCF_UP "Focus Fast"
#define L_FKEY_ROT_DN "Rotate Ccw"
#define L_FKEY_ROT_UP "Rotate Cw"
#define L_FKEY_ROTF_DN "Rotate Fast"
#define L_FKEY_ROTF_UP "Rotate Fast"
#define L_SUCCESS "成功"
#define L_ADD_STAR "添加恒星"
#define L_SUCCESS "成功"
#define L_FAILED "失败"
#define L_SLEWING_TO_STAR "指向目标"
#define L_RECENTER_STAR "将校准星居中"
#define L_SELECT_STAR "选择校准星"
#define L_LX200_NOTOK_1 "LX200命令"
#define L_LX200_NOTOK_2 "失败!"
#define L_LX200_SETVF_1 "设置值"
#define L_LX200_SETVF_2 "失败!"
#define L_LX200_GETVF_1 "获取值"
#define L_LX200_GETVF_2 "失败!"
#define L_LX200_SETTG_1 "设定目标"
#define L_LX200_SETTG_2 "失败!"
#define L_LX200_OBJSE_1 "未选择"
#define L_LX200_OBJSE_2 "目标!"
#define L_LX200_TGHOR_1 "目标位置"
#define L_LX200_TGHOR_2 "低于地平!"
#define L_LX200_TGOVH_1 "目标位置"
#define L_LX200_TGOVH_2 "超出限制!"
#define L_LX200_STNBF_1 "望远镜处"
#define L_LX200_STNBF_2 "于待机状态!"
#define L_LX200_PARKF_1 "望远镜"
#define L_LX200_PARKF_2 "完成停机!"
#define L_LX200_GOGOF_1 "Goto已"
#define L_LX200_GOGOF_2 "在进行!"
#define L_LX200_LIMTF_1 "目标"
#define L_LX200_LIMTF_2 "超出限制!"
#define L_LX200_HARDF_1 "Telescope"
#define L_LX200_HARDF_2 "h/w fault!"
#define L_LX200_GOMOF_1 "望远镜正"
#define L_LX200_GOMOF_2 "在移动!"
#define L_LX200_UNSPF_1 "Goto未知"
#define L_LX200_UNSPF_2 "错误!"
#define L_LX200_ERROR "错误"
#define L_LX200_ISAOK_1 "LX200命令"
#define L_LX200_ISAOK_2 "已完成!"
#define L_LX200_SETOK_1 "值"
#define L_LX200_SETOK_2 "已设置!"
#define L_LX200_GETOK_1 "值"
#define L_LX200_GETOK_2 "已获取!"
#define L_LX200_SNCOK_1 "望远镜"
#define L_LX200_SNCOK_2 "已同步!"
#define L_LX200_GOTOK_1 "指向"
#define L_LX200_GOTOK_2 "目标"

// ----------------------- u8g2_ext_catalog.cpp -------------------------

#define L_CAT_PER_UNK "Period Unknown"
#define L_CAT_PER_IRR "Period Irregular"
#define L_CAT_PER "Period"
#define L_CAT_UNK "Unknown"
#define L_CAT_OC "疏散星团"
#define L_CAT_GC "球状星团"
#define L_CAT_PN "行星状星云"
#define L_CAT_SG "螺旋星系"
#define L_CAT_EG "椭圆星系"
#define L_CAT_IG "不规则星系"
#define L_CAT_KNT "Knot"
#define L_CAT_SNR "超新星"
#define L_CAT_GAL "星系"
#define L_CAT_CN "发射星云"
#define L_CAT_STR "恒星"
#define L_CAT_PLA "行星"
#define L_CAT_CMT "彗星"
#define L_CAT_AST "小行星"

// ----------------------- u8g2_ext_input.cpp -------------------------

#define L_RIGHT_ASC "输入赤经"
#define L_DECLINATION "输入赤纬"
#define L_LOCAL_TIME "当地时间"
#define L_LATITUDE "纬度"
#define L_LONGITUDE "经度"
